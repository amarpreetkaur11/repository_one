import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componenet-trial',
  templateUrl: './componenet-trial.component.html',
  styleUrls: ['./componenet-trial.component.css']
})
export class ComponenetTrialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
