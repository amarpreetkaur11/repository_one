import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ComponentOneComponent } from './component-one/component-one.component';
import { ComponenetTrialComponent } from './componenet-trial/componenet-trial.component';


@NgModule({
  declarations: [
    AppComponent,
    ComponentOneComponent,
    ComponenetTrialComponent,
   
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
